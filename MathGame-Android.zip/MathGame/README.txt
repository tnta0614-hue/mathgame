Riazi-Baz (Android native, Kotlin)
1) Open this folder in Android Studio (File > Open).
2) Let Gradle sync (it will download Gradle 8.5 + Android Gradle Plugin 8.2.2).
3) Build > Build APK(s)  -> app/build/outputs/apk/debug/app-debug.apk
For a release build: Build > Generate Signed Bundle / APK, use your own keystore.
