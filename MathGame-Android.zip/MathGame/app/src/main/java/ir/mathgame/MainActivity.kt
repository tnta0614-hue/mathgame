package ir.mathgame

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

private class Q(val text: String, val ans: Int)
private class Bal(var x: Float, var y: Float, val v: Int, val t: String, val c: Int, var old: Boolean = false)

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("mg", Context.MODE_PRIVATE) }
    private val tone by lazy { ToneGenerator(AudioManager.STREAM_MUSIC, 70) }
    private val dens get() = resources.displayMetrics.density

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        menu()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun fa(n: Int) = n.toString().map { if (it in '0'..'9') "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    private fun dp(v: Int) = (v * dens).toInt()
    private fun best(k: String) = prefs.getInt(k, 0)
    private fun beep(ok: Boolean) {
        try { tone.startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK, 120) } catch (e: Exception) { }
    }

    private fun root(): LinearLayout {
        handler.removeCallbacksAndMessages(null)
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setBackgroundColor(0xFF1B1F3B.toInt())
        l.setPadding(dp(16), dp(36), dp(16), dp(20))
        l.layoutDirection = View.LAYOUT_DIRECTION_RTL
        setContentView(l)
        return l
    }

    private fun tv(t: String, size: Float): TextView {
        val v = TextView(this)
        v.text = t; v.textSize = size; v.setTextColor(Color.WHITE); v.gravity = Gravity.CENTER
        return v
    }

    private fun btn(t: String, size: Float, color: Int, click: () -> Unit): Button {
        val b = Button(this)
        b.text = t; b.textSize = size; b.setTextColor(Color.WHITE); b.setBackgroundColor(color); b.isAllCaps = false
        b.setOnClickListener { click() }
        return b
    }

    private fun lp(h: Int = -2, w: Float = 0f): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(-1, if (w > 0f) 0 else h, w)
        p.setMargins(0, dp(8), 0, dp(8))
        return p
    }

    private fun menu() {
        val l = root()
        val c = 0xFF3A3F7A.toInt()
        l.addView(tv("🧮 ریاضی‌باز", 30f), lp())
        l.addView(btn("⚡ سریع‌حساب  (رکورد ${fa(best("quick"))})", 18f, c) { quick() }, lp(dp(80)))
        l.addView(btn("🔢 الگوی عددی  (رکورد ${fa(best("seq"))})", 18f, c) { seq() }, lp(dp(80)))
        l.addView(btn("🎈 بالن‌ها  (رکورد ${fa(best("balloons"))})", 18f, c) { balloons() }, lp(dp(80)))
    }

    private fun endGame(key: String, score: Int) {
        val nb = score > best(key)
        if (nb) prefs.edit().putInt(key, score).apply()
        val l = root()
        val c = 0xFF3A3F7A.toInt()
        l.addView(tv(if (nb) "🏆 رکورد جدید!" else "پایان بازی", 28f), lp())
        l.addView(tv(fa(score), 72f), lp())
        l.addView(tv("رکورد: ${fa(best(key))}", 16f), lp())
        l.addView(btn("🔁 دوباره", 20f, c) { when (key) { "quick" -> quick(); "seq" -> seq(); else -> balloons() } }, lp(dp(70)))
        l.addView(btn("🏠 منو", 20f, c) { menu() }, lp(dp(70)))
        beep(nb)
    }

    private fun opts(ans: Int): List<Int> {
        val s = mutableSetOf(ans)
        while (s.size < 4) {
            val w = ans + (if (Random.nextBoolean()) 1 else -1) * Random.nextInt(1, 6)
            if (w >= 0) s.add(w)
        }
        return s.shuffled()
    }

    private fun choiceGame(key: String, secs: Int, gen: (Int) -> Q) {
        val l = root()
        var score = 0
        var t = secs
        var streak = 0
        var lock = false
        var ans = 0
        val bar = LinearLayout(this)
        val tvS = tv("امتیاز: ${fa(0)}", 18f)
        val tvT = tv("⏱ ${fa(secs)}", 18f)
        bar.addView(tvS, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(tvT, LinearLayout.LayoutParams(0, -2, 1f))
        val qv = tv("", 38f)
        qv.textDirection = View.TEXT_DIRECTION_LTR
        val fb = tv("", 16f)
        val grid = GridLayout(this)
        grid.columnCount = 2
        l.addView(bar, lp())
        l.addView(qv, lp(0, 1f))
        l.addView(grid, lp())
        l.addView(fb, lp())

        fun next() {
            val q = gen(score)
            ans = q.ans
            qv.text = q.text
            grid.removeAllViews()
            for (v in opts(q.ans)) {
                val b = btn(fa(v), 24f, 0xFF4C5BD4.toInt()) { }
                b.setOnClickListener {
                    if (lock) return@setOnClickListener
                    lock = true
                    if (v == ans) {
                        score++; streak++
                        b.setBackgroundColor(0xFF2F9E44.toInt()); beep(true)
                        if (streak % 5 == 0) { t += 3; fb.text = "⏱ +۳ ثانیه" } else fb.text = "✔"
                    } else {
                        streak = 0; t = max(0, t - 3)
                        b.setBackgroundColor(0xFFE03131.toInt()); beep(false)
                        fb.text = "✘ ۳ ثانیه کم شد"
                    }
                    tvS.text = "امتیاز: ${fa(score)}"
                    tvT.text = "⏱ ${fa(t)}"
                    handler.postDelayed({ lock = false; if (t > 0) next() }, 350)
                }
                val gp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
                gp.width = 0; gp.height = dp(90); gp.setMargins(dp(6), dp(6), dp(6), dp(6))
                grid.addView(b, gp)
            }
        }

        val tick = object : Runnable {
            override fun run() {
                t--
                tvT.text = "⏱ ${fa(max(t, 0))}"
                if (t <= 0) endGame(key, score) else handler.postDelayed(this, 1000)
            }
        }
        next()
        handler.postDelayed(tick, 1000)
    }

    private fun quick() = choiceGame("quick", 60) { sc ->
        val lv = 1 + sc / 5
        val ops = if (lv < 3) listOf("+", "−") else if (lv < 6) listOf("+", "−", "×") else listOf("+", "−", "×", "÷")
        val op = ops.random()
        val m = 5 + lv * 4
        val a: Int
        val b: Int
        val ans: Int
        when (op) {
            "+" -> { a = Random.nextInt(1, m + 1); b = Random.nextInt(1, m + 1); ans = a + b }
            "−" -> { a = Random.nextInt(2, m + 1); b = Random.nextInt(1, a + 1); ans = a - b }
            "×" -> { a = Random.nextInt(2, 4 + lv); b = Random.nextInt(2, 4 + lv); ans = a * b }
            else -> { b = Random.nextInt(2, 4 + lv); ans = Random.nextInt(2, 4 + lv); a = b * ans }
        }
        Q("${fa(a)} $op ${fa(b)}", ans)
    }

    private fun seq() = choiceGame("seq", 90) { sc ->
        val lv = 1 + sc / 4
        val s = ArrayList<Int>()
        when (Random.nextInt(if (lv < 3) 2 else 5)) {
            0 -> { val a = Random.nextInt(1, 20); val d = Random.nextInt(2, 4 + lv); for (i in 0..4) s.add(a + d * i) }
            1 -> { val d = Random.nextInt(2, 6 + lv); val a = d * 6 + Random.nextInt(1, 9); for (i in 0..4) s.add(a - d * i) }
            2 -> { val r = Random.nextInt(2, 4); var v = Random.nextInt(1, 4); for (i in 0..4) { s.add(v); v *= r } }
            3 -> { val o = Random.nextInt(0, 6); val st = Random.nextInt(1, 5); for (i in 0..4) s.add((st + i) * (st + i) + o) }
            else -> { val a = Random.nextInt(2, 5); val b = Random.nextInt(2, 7 + lv); var v = Random.nextInt(1, 10); for (i in 0..4) { s.add(v); v += if (i % 2 == 0) a else b } }
        }
        Q(s.take(4).joinToString(" ، ") { fa(it) } + " ، ؟", s[4])
    }

    private fun balloons() {
        val l = root()
        l.setPadding(0, 0, 0, 0)
        l.addView(BalloonView(this), LinearLayout.LayoutParams(-1, -1))
    }

    private inner class BalloonView(ctx: Context) : View(ctx) {
        private val bs = ArrayList<Bal>()
        private var target = Random.nextInt(6, 16)
        private var lives = 3
        private var score = 0
        private var sp = 0f
        private var last = 0L
        private var done = false
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val cols = intArrayOf(0xFFFF6B6B.toInt(), 0xFF4DABF7.toInt(), 0xFFFFD43B.toInt(), 0xFF69DB7C.toInt(), 0xFFDA77F2.toInt(), 0xFFFFA94D.toInt())

        private fun expr(v: Int): String {
            val ds = (2..9).filter { v % it == 0 && v / it <= 9 }
            return when (Random.nextInt(3)) {
                0 -> if (ds.isNotEmpty()) { val q = ds.random(); "${fa(q)}×${fa(v / q)}" } else "${fa(v + 1)}−${fa(1)}"
                1 -> { val b = Random.nextInt(1, 10); "${fa(v + b)}−${fa(b)}" }
                else -> { val a = Random.nextInt(1, max(2, v)); "${fa(a)}+${fa(v - a)}" }
            }
        }

        private fun hit() {
            lives--
            beep(false)
            if (lives <= 0 && !done) { done = true; post { endGame("balloons", score) } }
        }

        override fun onDraw(c: Canvas) {
            val d = dens
            val now = System.nanoTime()
            val dt = if (last == 0L) 0f else min(0.05f, (now - last) / 1e9f)
            last = now
            c.drawColor(0xFF1B1F3B.toInt())
            if (!done) {
                sp -= dt
                if (sp <= 0f) {
                    sp = max(0.5f, 1.1f - score * 0.012f)
                    val ok = Random.nextFloat() < 0.4f
                    var v = if (ok) target else max(1, target + (if (Random.nextBoolean()) 1 else -1) * Random.nextInt(1, 6))
                    if (!ok && v == target) v++
                    val m = (50 * d).toInt()
                    bs.add(Bal(Random.nextInt(m, max(m + 1, width - m)).toFloat(), height + 60f * d, v, expr(v), cols.random()))
                }
                val spd = (70f + score * 2.5f) * d
                val iter = bs.iterator()
                while (iter.hasNext()) {
                    val b = iter.next()
                    b.y -= spd * dt
                    if (b.y < -80f * d) {
                        if (b.v == target && !b.old) hit()
                        iter.remove()
                    }
                }
            }
            p.textAlign = Paint.Align.CENTER
            for (b in bs) {
                p.color = b.c
                c.drawOval(b.x - 40f * d, b.y - 50f * d, b.x + 40f * d, b.y + 50f * d, p)
                p.color = 0x66FFFFFF
                p.strokeWidth = 2f * d
                c.drawLine(b.x, b.y + 50f * d, b.x, b.y + 75f * d, p)
                p.color = 0xFF111111.toInt()
                p.textSize = 20f * d
                c.drawText(b.t, b.x, b.y + 7f * d, p)
            }
            p.textSize = 22f * d
            p.color = Color.WHITE
            p.textAlign = Paint.Align.LEFT
            c.drawText("❤ " + fa(lives), 16f * d, 36f * d, p)
            p.textAlign = Paint.Align.RIGHT
            c.drawText("⭐ " + fa(score), width - 16f * d, 36f * d, p)
            p.textAlign = Paint.Align.CENTER
            p.color = 0xFFFFD43B.toInt()
            p.textSize = 28f * d
            c.drawText("هدف: " + fa(target), width / 2f, 38f * d, p)
            if (!done) invalidate()
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            if (e.action == MotionEvent.ACTION_DOWN && !done) {
                val d = dens
                for (i in bs.indices.reversed()) {
                    val b = bs[i]
                    val dx = (e.x - b.x) / (46f * d)
                    val dy = (e.y - b.y) / (56f * d)
                    if (dx * dx + dy * dy <= 1f) {
                        bs.removeAt(i)
                        if (b.v == target) {
                            score++
                            beep(true)
                            if (score % 8 == 0) {
                                target = Random.nextInt(6, 16 + score / 8 * 3)
                                bs.forEach { it.old = true }
                            }
                        } else hit()
                        break
                    }
                }
            }
            return true
        }
    }
}
